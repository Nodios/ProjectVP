(function() {
    'use strict';

    angular.module('significant', []);
})();