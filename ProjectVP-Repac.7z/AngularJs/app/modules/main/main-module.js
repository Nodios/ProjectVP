(function() {
    'use strict';

    angular.module('earthquake.main', []);
})();