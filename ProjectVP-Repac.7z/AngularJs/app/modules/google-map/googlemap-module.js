(function() {
    'use strict';

    angular.module('googlemap', []);
})();