(function() {
    'use strict';

    angular.module('d3', []);
})();